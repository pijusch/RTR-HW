#########Running the code#################

Steps:

1. Open the html file in firefox browser.

The aim is to avoid falling objects and danger signs on the floor.
All the traps and objects are randomly generated and nothing has been hardcoded.


#############Compatibility################

This code was tested on firefox browser, and works fine on it. (Do not use chrome, things may go weird on it).

#############Controls####################

The camera controls are same as the assignment demands

1: Moves camera up
2: Moves camera down
i: Moves camera front
k: Moves camera back
j: Moves camera left
l: Moves camera right

w: Moves ball front
s: Moves ball back
a: Moves ball left
d: Moves ball right

Reach the end of the alley and click "right", to turn right.

HTML buttons
1. Rotate Left, rotates scene to left
2. Rotate Right, rotates scene to right
3. Add objects, increases the number of falling objects
4. Do not press, changes all the drawings to line drawings to see the entire scene at once (blue print of the scene)
