#########Running the code#################

Steps:

1. Open the html file in chrome browser.


#############Compatibility################

This code was tested on Chrome browser, and works fine on it. (Do not use Firefox, things may go weird on it).

#############Controlz####################

The camera controls are same as the assignment demands

1: Moves camera up
2: Moves camera down
w: Moves camera front
s: Moves camera back
a: Moves camera left
d: Moves camera right
5: Zoom in
6: Zoom out

Additional controls to interact with the object

7: rotates scene about z axis
8: opposite rotation


#############Bonus Task(s) ###################
1. All the objects are generated using 3dShape function in primitives.js. This is single function for drawing, cube, cylinder, cones, sphere etc.
2. Mouse can control the day-time (also, sun and moon rotation)
3. Try Pressing 'Do Not Press'

